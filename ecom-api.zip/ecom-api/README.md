# E-Commerce API (Node.js + MongoDB)

## Quick Start
```bash
# 1) Install
npm install

# 2) Configure environment
cp .env.example .env   # on Windows, copy manually
# edit .env with your MongoDB URI

# 3) Run in dev
npm run dev
```

## .env
```
PORT=5000
MONGO_URI=mongodb+srv://<username>:<password>@<cluster>.mongodb.net/ecom?retryWrites=true&w=majority
JWT_SECRET=supersecret
JWT_EXP=7d
```

## Test
Open http://localhost:5000/ -> should show "E-Commerce API running"
