import express from "express";
import { createProduct, updateProduct, deleteProduct, listProducts } from "../controllers/productController.js";
import { auth } from "../middlewares/auth.js";
const router = express.Router();

router.get("/", listProducts);
router.post("/", auth(["ADMIN"]), createProduct);
router.put("/:id", auth(["ADMIN"]), updateProduct);
router.delete("/:id", auth(["ADMIN"]), deleteProduct);

export default router;
