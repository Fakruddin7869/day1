import express from "express";
import { auth } from "../middlewares/auth.js";
import { listOrdersAdmin, updateOrderStatus } from "../controllers/adminController.js";
const router = express.Router();

router.use(auth(["ADMIN"]));
router.get("/orders", listOrdersAdmin);
router.patch("/orders/:id/status", updateOrderStatus);

export default router;
