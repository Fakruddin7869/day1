import express from "express";
import { auth } from "../middlewares/auth.js";
import { getCart, addOrUpdateItem, removeItem } from "../controllers/cartController.js";
const router = express.Router();

router.use(auth());
router.get("/", getCart);
router.post("/items", addOrUpdateItem);
router.delete("/items/:productId", removeItem);

export default router;
