import express from "express";
import { auth } from "../middlewares/auth.js";
import { checkout, payOrder, getOrders, getOrder } from "../controllers/orderController.js";
const router = express.Router();

router.use(auth());
router.post("/checkout", checkout);
router.post("/:id/pay", payOrder);
router.get("/", getOrders);
router.get("/:id", getOrder);

export default router;
