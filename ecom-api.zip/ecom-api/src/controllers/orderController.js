import mongoose from "mongoose";
import Cart from "../models/Cart.js";
import Order from "../models/Order.js";
import Product from "../models/Product.js";
import Payment from "../models/Payment.js";
import { addJob } from "../utils/jobQueue.js";
import { sendEmail } from "../utils/email.js";

export const checkout = async (req, res, next) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const cart = await Cart.findOne({ userId: req.user.id }).populate("items.productId").session(session);
    if (!cart || cart.items.length === 0) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ message: "Cart is empty" });
    }
    for (const item of cart.items) {
      const prod = await Product.findById(item.productId._id).session(session);
      if (prod.availableStock < item.quantity) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({ message: `Insufficient stock for ${prod.name}` });
      }
      prod.availableStock -= item.quantity;
      prod.reservedStock += item.quantity;
      await prod.save({ session });
    }

    const orderItems = cart.items.map(i => ({
      productId: i.productId._id,
      quantity: i.quantity,
      priceAtPurchase: i.productId.price
    }));
    const totalAmount = orderItems.reduce((acc, it) => acc + it.priceAtPurchase * it.quantity, 0);
    const order = await Order.create([{
      userId: req.user.id,
      items: orderItems,
      totalAmount,
      status: "PENDING_PAYMENT"
    }], { session });

    cart.items = [];
    await cart.save({ session });

    await session.commitTransaction();
    session.endSession();

    res.status(201).json(order[0]);
  } catch (err) {
    await session.abortTransaction();
    session.endSession();
    next(err);
  }
};

export const payOrder = async (req, res, next) => {
  const orderId = req.params.id;
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const order = await Order.findById(orderId).session(session);
    if (!order) { await session.abortTransaction(); session.endSession(); return res.status(404).json({ message: "Order not found" }); }
    if (order.status !== "PENDING_PAYMENT") { await session.abortTransaction(); session.endSession(); return res.status(400).json({ message: "Order not in pending state" }); }

    const payment = await Payment.create([{ orderId, transactionId: "txn_" + Date.now(), amount: order.totalAmount, status: "SUCCESS" }], { session });

    for (const item of order.items) {
      const prod = await Product.findById(item.productId).session(session);
      prod.reservedStock -= item.quantity;
      if (prod.reservedStock < 0) prod.reservedStock = 0;
      await prod.save({ session });
    }
    order.status = "PAID";
    order.paidAt = new Date();
    await order.save({ session });

    await session.commitTransaction();
    session.endSession();

    addJob(async () => {
      await sendEmail({ to: "user@example.com", subject: "Order confirmed", text: `Order ${order._id} is confirmed.` });
    }, 1000);

    res.json({ order, payment: payment[0] });
  } catch (err) {
    await session.abortTransaction();
    session.endSession();
    next(err);
  }
};

export const getOrders = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;
    const orders = await Order.find({ userId: req.user.id }).sort({ createdAt: -1 }).skip(Number(skip)).limit(Number(limit));
    res.json(orders);
  } catch (err) { next(err); }
};

export const getOrder = async (req, res, next) => {
  try {
    const order = await Order.findOne({ _id: req.params.id, userId: req.user.id }).populate("items.productId");
    if (!order) return res.status(404).json({ message: "Not found" });
    res.json(order);
  } catch (err) { next(err); }
};
