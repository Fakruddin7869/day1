import Order from "../models/Order.js";
import Product from "../models/Product.js";

export const listOrdersAdmin = async (req, res, next) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (status) filter.status = status;
    const skip = (page - 1) * limit;
    const orders = await Order.find(filter).skip(Number(skip)).limit(Number(limit)).sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) { next(err); }
};


export const updateOrderStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: "Order not found" });

    if (status === "CANCELLED" && order.status === "PENDING_PAYMENT") {
      for (const item of order.items) {
        const prod = await Product.findById(item.productId);
        prod.reservedStock -= item.quantity;
        if (prod.reservedStock < 0) prod.reservedStock = 0;
        prod.availableStock += item.quantity;
        await prod.save();
      }
    }

    order.status = status;
    await order.save();

    res.json(order);
  } catch (err) { next(err); }
};
