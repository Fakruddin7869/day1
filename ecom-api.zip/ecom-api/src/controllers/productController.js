import Product from "../models/Product.js";

export const createProduct = async (req, res, next) => {
  try {
    const { name, price, description, availableStock } = req.body;
    const p = await Product.create({ name, price, description, availableStock: availableStock || 0 });
    res.status(201).json(p);
  } catch (err) { next(err); }
};

export const updateProduct = async (req, res, next) => {
  try {
    const p = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(p);
  } catch (err) { next(err); }
};

export const deleteProduct = async (req, res, next) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted" });
  } catch (err) { next(err); }
};

export const listProducts = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, sortBy = "name", order = "asc", name } = req.query;
    const filter = {};
    if (name) filter.name = { $regex: name, $options: "i" };
    const skip = (page - 1) * limit;
    const products = await Product.find(filter).sort({ [sortBy]: order === "asc" ? 1 : -1 }).skip(Number(skip)).limit(Number(limit));
    const total = await Product.countDocuments(filter);
    res.json({ products, total, page: Number(page), pages: Math.ceil(total/limit) });
  } catch (err) { next(err); }
};
