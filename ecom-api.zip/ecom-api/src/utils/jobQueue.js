const jobs = [];

export const addJob = (fn, delay = 0) => {
  const job = { fn, delay, id: Date.now() + Math.random() };
  jobs.push(job);
  setTimeout(async () => {
    try {
      await fn();
    } catch (err) {
      console.error("Background job error:", err);
    }
  }, delay);
  return job.id;
};

export const listJobs = () => jobs;
