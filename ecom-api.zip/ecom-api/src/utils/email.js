export const sendEmail = async ({ to, subject, text }) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`Email sent to ${to}: ${subject}`);
      resolve(true);
    }, 1000);
  });
};
