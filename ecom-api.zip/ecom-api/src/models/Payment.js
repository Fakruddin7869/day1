import mongoose from "mongoose";

const PaymentSchema = new mongoose.Schema({
  orderId: { type: mongoose.Schema.Types.ObjectId, ref: "Order" },
  transactionId: String,
  amount: Number,
  status: { type: String, enum: ["SUCCESS","FAILED"], required: true }
}, { timestamps: true });

export default mongoose.model("Payment", PaymentSchema);
