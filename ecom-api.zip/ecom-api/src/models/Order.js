import mongoose from "mongoose";

const OrderItem = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
  quantity: { type: Number, required: true },
  priceAtPurchase: { type: Number, required: true }
}, { _id: false });

const OrderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  items: [OrderItem],
  totalAmount: { type: Number, required: true },
  status: { type: String, enum: ["PENDING_PAYMENT","PAID","SHIPPED","DELIVERED","CANCELLED"], default: "PENDING_PAYMENT" },
  paidAt: Date
}, { timestamps: true });

export default mongoose.model("Order", OrderSchema);
